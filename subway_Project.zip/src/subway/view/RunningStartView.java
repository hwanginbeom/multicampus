package subway.view;

public class RunningStartView {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
